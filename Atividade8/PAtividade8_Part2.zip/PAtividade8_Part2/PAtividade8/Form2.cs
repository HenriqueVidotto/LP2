﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string frase;
            int d = 0;
            frase = rchtxtFrase.Text;


            char[] ArrayText = frase.ToCharArray();

            for (int i = 0; i < frase.Length; i++)
            {
                if (char.IsWhiteSpace(ArrayText[i]))
                {
                    d = d + 1;
                }
            }
            txtResult.Text = Convert.ToString(d);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase;
            int d = 0, i = 0;
            frase = rchtxtFrase.Text;


            char[] ArrayText = frase.ToCharArray();

            while (i < frase.Length)
            {
                if (ArrayText[i] == 'r' || ArrayText[i] == 'R')
                {
                    d = d + 1;
                }
                i++;
            }

            txtResult.Text = Convert.ToString(d);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            string frase;
            int d = 0;
            frase = rchtxtFrase.Text;


            char[] ArrayText = frase.ToCharArray();

            for (int i = 1; i < frase.Length; i++)
            {
                if (ArrayText[i] == ArrayText[i-1])
                {
                    d = d + 1;
                }
            }

            txtResult.Text = Convert.ToString(d);
        }



    }
}
