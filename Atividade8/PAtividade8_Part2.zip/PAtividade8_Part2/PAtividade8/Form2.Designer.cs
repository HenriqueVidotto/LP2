﻿namespace PAtividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(165, 30);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(496, 218);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(165, 325);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(147, 81);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnPar
            // 
            this.btnPar.Location = new System.Drawing.Point(489, 325);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(172, 81);
            this.btnPar.TabIndex = 2;
            this.btnPar.Text = "pares";
            this.btnPar.UseVisualStyleBackColor = true;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(318, 325);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(165, 81);
            this.btnR.TabIndex = 3;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(165, 279);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(496, 20);
            this.txtResult.TabIndex = 4;
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 567);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "FtmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.TextBox txtResult;
    }
}