﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnSaber_Click(object sender, EventArgs e)
        {
            string fraseMaiuscula,fraseReverse = "",frase;

            


            frase = txtFrase.Text;


            frase = frase.Replace(" ", "");

            fraseMaiuscula = frase.ToUpper();

            char[] Letras = fraseMaiuscula.ToCharArray();

          
            Array.Reverse(Letras);
            for (int i = 0; i < frase.Length; i++)
            {
                fraseReverse = fraseReverse + Letras[i];
            }

            if (fraseMaiuscula == fraseReverse)
            {
                txtResult.Text = "é palíndromo";
            }
            else
	             {
                     txtResult.Text = "NÃO É palíndromo";
	            }
        }
    }
}
